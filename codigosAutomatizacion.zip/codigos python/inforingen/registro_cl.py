from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

import time

PATH = "C:\Program Files (x86)\chromedriver.exe"
driver = webdriver.Chrome(PATH)

driver.get("https://www.infor-ingen.com")
print(driver.title)

#ingreso a la página de inicio de sesión

driver.find_element_by_link_text('Mi cuenta').click()
driver.find_element_by_link_text('Continuar').click()

#rellenado de datos para registro

driver.find_element_by_name('firstname').send_keys('John')
driver.find_element_by_name('lastname').send_keys('Doe')
driver.find_element_by_name('email').send_keys('tareacriptova@gmail.com')
driver.find_element_by_name('telephone').send_keys('9999')
driver.find_element_by_name('company').send_keys('')
driver.find_element_by_name('address_1').send_keys('calle falsa')
driver.find_element_by_name('city').send_keys('Santiago')
driver.find_element_by_name('password').send_keys('p455g3n3r1c4')
driver.find_element_by_name('confirm').send_keys('p455g3n3r1c4')
time.sleep(2)
driver.find_element_by_xpath("//select[@name='country_id']/option[text()='Chile']").click()
driver.find_element_by_xpath("//select[@name='zone_id']/option[text()='Region Metropolitana']").click()
driver.find_element_by_name('agree').click()
time.sleep(2)
driver.find_element_by_css_selector("[value^='Continuar']").click()
