from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

import time

PATH = "C:\Program Files (x86)\chromedriver.exe"
driver = webdriver.Chrome(PATH)

driver.get("https://www.infor-ingen.com")
print(driver.title)

#ingreso a la página de inicio de sesión

driver.find_element_by_link_text('Mi cuenta').click()
driver.find_element_by_name('email').send_keys('tareacriptova@gmail.com')
driver.find_element_by_name('password').send_keys('p455g3n3r1c4')
time.sleep(2)
driver.find_element_by_css_selector("[value^='Inicio de sesión']").click()
