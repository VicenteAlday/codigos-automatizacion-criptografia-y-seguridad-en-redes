from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

import time

PATH = "C:\Program Files (x86)\chromedriver.exe"
driver = webdriver.Chrome(PATH)

driver.get("https://www.pccomponentes.com/")
print(driver.title)

driver.find_element_by_class_name('c-user-menu__link.qa-user-login-button').click()
time.sleep(2)
driver.find_element_by_link_text('He olvidado mi contraseña').click()
driver.find_element_by_name('email').send_keys('tareacriptova@gmail.com')

#captcha
