from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

import time

PATH = "C:\Program Files (x86)\chromedriver.exe"
driver = webdriver.Chrome(PATH)

driver.get("https://www.pccomponentes.com/")
print(driver.title)

driver.find_element_by_class_name('c-user-menu__link.qa-user-login-button').click()
time.sleep(2)
driver.find_element_by_css_selector("[name^='username']").send_keys('tareacriptova@gmail.com')
driver.find_element_by_css_selector("[name^='password']").send_keys('p455g3n3r1c4')
time.sleep(2)
driver.find_element_by_css_selector("[type^='submit']").click()

#Cambiar contraseña
time.sleep(2)
driver.find_element_by_id("user-menu-panel").click()
time.sleep(2)
driver.find_element_by_class_name("qa-user-login-sub-4").click()
driver.find_element_by_css_selector("[name^='userPassword[password]']").send_keys('p455g3n3r1c4')
driver.find_element_by_css_selector("[name^='userPassword[passwordConfirm]']").send_keys('p455g3n3r1c4')
driver.find_element_by_css_selector("[name^='userPassword[passwordConfirm2]']").send_keys('p455g3n3r1c4')
driver.find_element_by_css_selector("[name^='userPassword[create]']").click()
